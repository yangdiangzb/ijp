import javafx.event.ActionEvent;

public class WorldController {
	
    public void sayHello(ActionEvent event) {
    	System.out.println("Hello World");
     }
}
