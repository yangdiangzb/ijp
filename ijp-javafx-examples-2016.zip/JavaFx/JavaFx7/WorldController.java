import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.MenuItem;

public class WorldController {
	
	@FXML
	private TextField messageBox;

	@FXML
	private MenuItem aboutItem;

	public void doAbout(ActionEvent event) {
    	messageBox.setText("this is about me");
	}
	
	public void disable(ActionEvent event) {
    	aboutItem.setDisable(true);
	}
}
